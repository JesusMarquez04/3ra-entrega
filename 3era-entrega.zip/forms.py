from django import forms
from .models import Clase1, Clase2, Clase3

class FormularioInsertar(forms.ModelForm):
    class Meta:
        model = Clase1
        fields = ['campo1', 'campo2']

class FormularioBuscar(forms.ModelForm):
    class Meta:
        model = Clase1
        fields = ['campo1']