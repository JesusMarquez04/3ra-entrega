from django.db import models

class Clase1(models.Model):
    campo1 = models.CharField(max_length=200)
    campo2 = models.CharField(max_length=200)

class Clase2(models.Model):
    campo1 = models.CharField(max_length=200)
    campo2 = models.CharField(max_length=200)

class Clase3(models.Model):
    campo1 = models.CharField(max_length=200)
    campo2 = models.CharField(max_length=200)