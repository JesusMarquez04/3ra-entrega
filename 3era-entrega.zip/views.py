from django.shortcuts import render
from .forms import FormularioInsertar, FormularioBuscar
from .models import Clase1, Clase2, Clase3

def vista_insertar(request):
    if request.method == 'POST':
        form = FormularioInsertar(request.POST)
        if form.is_valid():
            form.save()
            return render(request, 'exito.html')
    else:
        form = FormularioInsertar()
    return render(request, 'formulario.html', {'form': form})

def vista_buscar(request):
    if request.method == 'POST':
        form = FormularioBuscar(request.POST)
        if form.is_valid():
            clave = form.cleaned_data['cam